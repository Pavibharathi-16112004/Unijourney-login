# Simple Login Project (HTML/CSS/JS + FastAPI + MySQL)

## 1. MySQL setup
- MySQL Workbench or terminal la login pannunga
- `backend/schema.sql` file run pannunga (idhu database + users table create pannum)

## 2. Backend setup (FastAPI)
```
cd backend
pip install -r requirements.txt
```
`main.py` file la `YOUR_MYSQL_PASSWORD` ah unga actual MySQL password kooda maathunga.

Run pannunga:
```
uvicorn main:app --reload
```
Terminal la `http://127.0.0.1:8000` nu varum. Browser la andha URL open pannitu
`{"status":"Backend is running"}` varudha nu check pannunga.

## 3. Frontend (Chrome la run panna)
`frontend/index.html` file ah direct double-click pannitu Chrome la open pannunga.
(File path mathiri `file:///C:/.../index.html` varum - adhu problem illa, CORS backend la already allow pannirukom.)

## 4. Test flow
1. `signup.html` la account create pannunga
2. `index.html` (login page) ku po, andha email/password kudunga
3. "Login successful" message varanum

## Notes
- MySQL service start aagi irukanum (XAMPP/WAMP/standalone service)
- FastAPI terminal running-a irukanum, illa na "Could not reach server" error varum
